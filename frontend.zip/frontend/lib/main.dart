import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';

// Auth
import 'modules/auth/login_page.dart';
// import 'modules/auth/register_page.dart';
import 'modules/auth/forgot-pass_page.dart';
import 'modules/auth/email_page.dart';
import 'modules/auth/reset_password_page.dart';
import 'modules/auth/expired-link_page.dart';

// Splash
import 'modules/splash_page.dart';

// Admin
import 'modules/admin/dashboard/dashboard_page.dart';
import 'modules/admin/employee/employee_page.dart';
import 'modules/admin/attendance/attendance_page.dart';
import 'modules/admin/assignment/assignment_page.dart';
import 'modules/admin/letter/letter_page.dart';
import 'modules/admin/profile/profile_page.dart';

// User
import 'modules/user/dashboard/dashboard_page.dart';
import 'modules/user/attendance/attendance_page.dart';
import 'modules/user/attendance/user_attendance_form_page.dart';
import 'modules/user/assignment/assignment_page.dart';
import 'modules/user/letters/letters_page.dart';
import 'modules/user/profile/profile_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize date formatting with error handling
  try {
    await initializeDateFormatting('id_ID', null);
  } catch (e) {
    print('Date formatting initialization failed: $e');
    // Continue anyway, app can work without Indonesian locale
  }

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BPR Absence',
      theme: ThemeData(useMaterial3: true, fontFamily: 'Roboto'),
      initialRoute: '/', // Splash pertama
      routes: {
        // General
        '/': (_) => const SplashPage(),
        '/login': (_) => const LoginPage(),
        // '/register': (_) => const RegisterPage(),
        '/forgot-password': (_) => const ForgotPassPage(),
        '/forgot-password/email': (_) => const EmailPage(),
        '/forgot-password/email/Expired-link': (_) => const LinkExpiredPage(),
        '/forgot-password/reset-password': (_) => const ResetPasswordPage(),

        // Admin routes
        '/admin/dashboard': (_) => const AdminDashboardPage(),
        '/admin/employees': (_) => const EmployeePage(),
        '/admin/attendance': (_) => const AttendancePage(),
        '/admin/assignment': (_) => const AssignmentPage(),
        '/admin/letter': (_) => const LetterPage(),
        '/admin/profile': (_) => const ProfilePage(),

        // User routes
        '/user/dashboard': (_) => const UserDashboardPage(),
        '/user/attendance': (_) => const UserAttendancePage(),
        '/user/attendance/form': (_) => const UserAttendanceFormPage(),
        '/user/assignment': (_) => const UserAssignmentPage(),
        '/user/letter': (_) => const UserLettersPage(),
        '/user/profile': (_) => const UserProfilePage(),
      },
    );
  }
}
