import 'package:flutter/material.dart';
import 'package:frontend/core/constants/colors.dart';

class AttendanceStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const AttendanceStat({
    super.key,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 12, color: Colors.black87),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
      ],
    );
  }
}
