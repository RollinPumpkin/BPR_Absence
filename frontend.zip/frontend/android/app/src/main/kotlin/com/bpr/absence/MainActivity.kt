package com.bpr.absence

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()